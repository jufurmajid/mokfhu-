extends Node3D

## 240 x 240 m semi-arid combat map. All geometry is generated from lightweight meshes.
const HALF_SIZE := 120.0
const GRID_CELLS := 64
const STEP := (HALF_SIZE * 2.0) / GRID_CELLS

var ground_material: StandardMaterial3D
var road_material: StandardMaterial3D
var wall_material: StandardMaterial3D
var roof_material: StandardMaterial3D
var dark_material: StandardMaterial3D
var scrub_material: StandardMaterial3D

func _ready() -> void:
	_setup_materials()
	_build_terrain()
	_build_roads()
	_build_village()
	_build_defenses()
	_build_scrub()
	_add_marker("Spawn_West", Vector3(-94, terrain_height(-94, 0) + 0.15, 0), Color(0.26, 0.45, 0.58))
	_add_marker("Spawn_East", Vector3(94, terrain_height(94, 0) + 0.15, 0), Color(0.62, 0.32, 0.23))
	_add_marker("Capture_A_Road_Junction", Vector3(-52, terrain_height(-52, 0) + 0.2, 0), Color(0.74, 0.62, 0.34))
	_add_marker("Capture_B_Village", Vector3(5, terrain_height(5, 4) + 0.2, 4), Color(0.74, 0.62, 0.34))
	_add_marker("Capture_C_Ridge", Vector3(70, terrain_height(70, -50) + 0.2, -50), Color(0.74, 0.62, 0.34))

func _setup_materials() -> void:
	ground_material = StandardMaterial3D.new()
	ground_material.vertex_color_use_as_albedo = true
	ground_material.roughness = 1.0
	ground_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	road_material = _mat(Color(0.22, 0.22, 0.20), 0.98)
	wall_material = _mat(Color(0.43, 0.40, 0.34), 0.96)
	roof_material = _mat(Color(0.30, 0.29, 0.26), 0.92)
	dark_material = _mat(Color(0.16, 0.17, 0.16), 0.92)
	scrub_material = _mat(Color(0.28, 0.30, 0.23), 1.0)

func _mat(color: Color, rough: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	return m

func _build_terrain() -> void:
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors := PackedColorArray()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	for z_index in range(GRID_CELLS + 1):
		for x_index in range(GRID_CELLS + 1):
			var x := -HALF_SIZE + float(x_index) * STEP
			var z := -HALF_SIZE + float(z_index) * STEP
			var h := terrain_height(x, z)
			vertices.append(Vector3(x, h, z))
			var nx := terrain_height(x - STEP, z) - terrain_height(x + STEP, z)
			var nz := terrain_height(x, z - STEP) - terrain_height(x, z + STEP)
			normals.append(Vector3(nx, STEP * 2.0, nz).normalized())
			uvs.append(Vector2(float(x_index) / GRID_CELLS, float(z_index) / GRID_CELLS))
			var variation := sin(x * 0.31 + z * 0.17) * 0.035 + cos(z * 0.23 - x * 0.13) * 0.025
			var lowland := smoothstep(13.0, 3.0, h)
			var base := Color(0.39, 0.37, 0.30).lerp(Color(0.46, 0.43, 0.34), lowland)
			colors.append(Color(base.r + variation, base.g + variation, base.b + variation * 0.7, 1.0))
	for z_index in range(GRID_CELLS):
		for x_index in range(GRID_CELLS):
			var a := z_index * (GRID_CELLS + 1) + x_index
			var b := a + 1
			var c := a + GRID_CELLS + 1
			var d := c + 1
			indices.append_array(PackedInt32Array([a, c, b, b, c, d]))
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.surface_set_material(0, ground_material)
	var mi := MeshInstance3D.new()
	mi.name = "Terrain_240m"
	mi.mesh = mesh
	add_child(mi)
	var body := StaticBody3D.new()
	body.name = "Terrain_Collision"
	var shape := CollisionShape3D.new()
	shape.shape = mesh.create_trimesh_shape()
	body.add_child(shape)
	add_child(body)

func terrain_height(x: float, z: float) -> float:
	var ridge := 9.0 * exp(-pow((x - 79.0) / 31.0, 2.0) - pow((z + 50.0) / 53.0, 2.0))
	var north_hills := 6.5 * exp(-pow((x + 20.0) / 66.0, 2.0) - pow((z + 105.0) / 25.0, 2.0))
	var south_hills := 7.0 * exp(-pow((x - 25.0) / 70.0, 2.0) - pow((z - 108.0) / 24.0, 2.0))
	var roll := sin(x * 0.035 + z * 0.023) * 1.5 + cos(z * 0.041 - x * 0.018) * 1.0
	var village_flat := 2.5 * exp(-pow(x / 47.0, 2.0) - pow(z / 43.0, 2.0))
	return maxf(0.0, ridge + north_hills + south_hills + roll - village_flat)

func _build_roads() -> void:
	_add_road(Vector2(-109, 0), Vector2(110, 0), 8.0, 0.14)
	_add_road(Vector2(0, -82), Vector2(0, 75), 6.0, 0.12)
	_add_road(Vector2(-74, 38), Vector2(72, -54), 5.0, 0.12)
	# Broken road shoulders create an older, weathered edge without expensive props.
	_add_road(Vector2(-106, -6), Vector2(108, -6), 1.2, 0.16, Color(0.34, 0.31, 0.25))
	_add_road(Vector2(-106, 6), Vector2(108, 6), 1.2, 0.16, Color(0.34, 0.31, 0.25))

func _add_road(start: Vector2, finish: Vector2, width: float, lift: float, edge_color: Color = Color(0.22, 0.22, 0.20)) -> void:
	var delta := finish - start
	var side := Vector2(-delta.y, delta.x).normalized() * width * 0.5
	var verts := PackedVector3Array()
	var steps := maxi(2, int(delta.length() / 5.0))
	for i in range(steps + 1):
		var t := float(i) / steps
		var p := start.lerp(finish, t)
		for sign in [-1.0, 1.0]:
			var q := p + side * sign
			verts.append(Vector3(q.x, terrain_height(q.x, q.y) + lift, q.y))
	var idx := PackedInt32Array()
	for i in range(steps):
		var a := i * 2
		idx.append_array(PackedInt32Array([a, a + 1, a + 2, a + 1, a + 3, a + 2]))
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var road := MeshInstance3D.new()
	road.mesh = mesh
	road.material_override = _mat(edge_color, 0.99)
	add_child(road)

func _build_village() -> void:
	# Irregular blocks, a small courtyard and damaged walls form a compact rural settlement.
	var plots := [
		Vector3(-28, 0, -24), Vector3(-7, 0, -27), Vector3(18, 0, -24), Vector3(34, 0, -6),
		Vector3(-29, 0, 15), Vector3(-10, 0, 26), Vector3(14, 0, 21), Vector3(32, 0, 17),
		Vector3(4, 0, -2), Vector3(-43, 0, -5), Vector3(45, 0, 5)
	]
	for i in range(plots.size()):
		var p: Vector3 = plots[i]
		var h := terrain_height(p.x, p.z)
		var sx := 9.0 if i % 3 == 0 else 7.0
		var sz := 7.0 if i % 2 == 0 else 8.5
		_add_house("Rural_House_%02d" % i, Vector3(p.x, h, p.z), Vector2(sx, sz), 4.4 + float(i % 3) * 0.3, i % 4 == 0)
	# A ruined checkpoint facing the western approach.
	_add_wall(Vector3(-57, terrain_height(-57, 0), 0), Vector3(1.1, 2.1, 13.0), 0.22)
	_add_wall(Vector3(-47, terrain_height(-47, 0), -6.5), Vector3(9.0, 2.0, 0.8), -0.08)
	_add_wall(Vector3(-47, terrain_height(-47, 0), 6.2), Vector3(9.0, 1.4, 0.7), 0.05)

func _add_house(label: String, center: Vector3, footprint: Vector2, height: float, damaged: bool) -> void:
	var root := StaticBody3D.new()
	root.name = label
	root.position = center
	var body_mesh := BoxMesh.new()
	body_mesh.size = Vector3(footprint.x, height, footprint.y)
	var shell := MeshInstance3D.new()
	shell.mesh = body_mesh
	shell.position.y = height * 0.5
	shell.material_override = wall_material
	root.add_child(shell)
	var collider := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = body_mesh.size
	collider.shape = box
	collider.position.y = height * 0.5
	root.add_child(collider)
	var roof_mesh := BoxMesh.new()
	roof_mesh.size = Vector3(footprint.x + 0.8, 0.35, footprint.y + 0.8)
	var roof := MeshInstance3D.new()
	roof.mesh = roof_mesh
	roof.position.y = height + 0.12
	roof.material_override = roof_material
	root.add_child(roof)
	# Recessed-looking dark window lintels on opposite facades.
	for side in [-1.0, 1.0]:
		var window_mesh := BoxMesh.new()
		window_mesh.size = Vector3(1.15, 0.85, 0.12)
		var window := MeshInstance3D.new()
		window.mesh = window_mesh
		window.position = Vector3(0, height * 0.62, side * (footprint.y * 0.5 + 0.07))
		window.material_override = dark_material
		root.add_child(window)
	if damaged:
		var break_mesh := BoxMesh.new()
		break_mesh.size = Vector3(footprint.x * 0.25, 1.2, footprint.y * 0.5)
		var break_piece := MeshInstance3D.new()
		break_piece.mesh = break_mesh
		break_piece.position = Vector3(footprint.x * 0.34, height + 0.15, 0)
		break_piece.rotation.z = 0.22
		break_piece.material_override = wall_material
		root.add_child(break_piece)
	add_child(root)

func _add_wall(pos: Vector3, dimensions: Vector3, yaw: float) -> void:
	var body := StaticBody3D.new()
	body.name = "Concrete_Barrier"
	body.position = pos
	body.rotation.y = yaw
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	var visual := MeshInstance3D.new()
	visual.mesh = mesh
	visual.position.y = dimensions.y * 0.5
	visual.material_override = wall_material
	body.add_child(visual)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = dimensions
	shape.shape = box
	shape.position.y = dimensions.y * 0.5
	body.add_child(shape)
	add_child(body)

func _build_defenses() -> void:
	for i in range(8):
		var x := -83.0 + float(i) * 23.0
		var z := -14.0 if i % 2 == 0 else 14.0
		_add_sandbag(Vector3(x, terrain_height(x, z), z), 5.5, 1.0)
	# Shallow, traversable trench lines on the ridge approach.
	for i in range(4):
		var x := 54.0 + float(i) * 8.0
		var z := -78.0 + float(i % 2) * 9.0
		_add_sandbag(Vector3(x, terrain_height(x, z), z), 7.0, 0.8)
	# A few scattered roadblocks along the village perimeter.
	for p in [Vector2(-50, -16), Vector2(-50, 17), Vector2(50, -15), Vector2(54, 17)]:
		_add_wall(Vector3(p.x, terrain_height(p.x, p.y), p.y), Vector3(2.2, 1.2, 2.4), 0.0)

func _add_sandbag(pos: Vector3, length: float, rows: float) -> void:
	var body := StaticBody3D.new()
	body.name = "Sandbag_Position"
	body.position = pos
	var mesh := BoxMesh.new()
	mesh.size = Vector3(length, rows, 1.0)
	var visual := MeshInstance3D.new()
	visual.mesh = mesh
	visual.position.y = rows * 0.5
	visual.material_override = _mat(Color(0.39, 0.36, 0.28), 1.0)
	body.add_child(visual)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = mesh.size
	shape.shape = box
	shape.position.y = rows * 0.5
	body.add_child(shape)
	add_child(body)

func _build_scrub() -> void:
	# Instanced low shrubs and sparse trees, clustered away from the roads and the town.
	var bush_mesh := SphereMesh.new()
	bush_mesh.radius = 0.72
	bush_mesh.height = 1.0
	var multi := MultiMesh.new()
	multi.transform_format = MultiMesh.TRANSFORM_3D
	multi.mesh = bush_mesh
	var candidates: Array[Transform3D] = []
	for z in range(-108, 109, 9):
		for x in range(-108, 109, 9):
			var xf := float(x) + sin(float(z) * 0.31 + float(x) * 0.09) * 3.5
			var zf := float(z) + cos(float(x) * 0.16 - float(z) * 0.21) * 3.5
			if absf(xf) < 53.0 and absf(zf) < 42.0:
				continue
			if absf(zf) < 7.0 or absf(xf) < 4.0:
				continue
			if int(absf(xf * 1.7 + zf * 0.8)) % 3 == 0:
				continue
			var scale := 0.65 + float(int(absf(xf + zf * 3.0)) % 70) / 100.0
			candidates.append(Transform3D(Basis().scaled(Vector3(scale, scale * 0.52, scale)), Vector3(xf, terrain_height(xf, zf) + 0.35, zf)))
	multi.instance_count = candidates.size()
	for i in range(candidates.size()):
		multi.set_instance_transform(i, candidates[i])
	var shrubs := MultiMeshInstance3D.new()
	shrubs.name = "Sparse_Scrub_Instances"
	shrubs.multimesh = multi
	shrubs.material_override = scrub_material
	add_child(shrubs)

func _add_marker(label: String, pos: Vector3, color: Color) -> void:
	var marker := Marker3D.new()
	marker.name = label
	marker.position = pos
	add_child(marker)
	var pole := MeshInstance3D.new()
	var pole_mesh := CylinderMesh.new()
	pole_mesh.top_radius = 0.07
	pole_mesh.bottom_radius = 0.07
	pole_mesh.height = 4.0
	pole.mesh = pole_mesh
	pole.position.y = 2.0
	pole.material_override = dark_material
	marker.add_child(pole)
	var flag := MeshInstance3D.new()
	var flag_mesh := BoxMesh.new()
	flag_mesh.size = Vector3(1.5, 0.75, 0.08)
	flag.mesh = flag_mesh
	flag.position = Vector3(0.78, 3.45, 0)
	flag.material_override = _mat(color, 0.88)
	marker.add_child(flag)
